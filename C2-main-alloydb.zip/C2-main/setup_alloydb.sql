-- setup_alloydb.sql
-- Creates the embeddings table and indexes for the patent analysis pipeline.
-- Run this once against your AlloyDB instance, or let alloydb_client.py auto-create.

CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS embeddings (
    unique_id   TEXT PRIMARY KEY,
    sub_id      TEXT DEFAULT '',
    collection  TEXT NOT NULL DEFAULT '',
    text        TEXT DEFAULT '',
    embedding   vector(768),
    metadata    JSONB DEFAULT '{}'
);

-- Collection-based lookups (filter by drug/collection)
CREATE INDEX IF NOT EXISTS idx_embeddings_collection
    ON embeddings (collection);

-- Filename lookups within metadata (used by get, delete where filename=...)
CREATE INDEX IF NOT EXISTS idx_embeddings_metadata_filename
    ON embeddings ((metadata->>'filename'));

-- Chunk index lookups (used by get_all_chunks ordering)
CREATE INDEX IF NOT EXISTS idx_embeddings_metadata_chunk_index
    ON embeddings ((metadata->>'chunk_index'));

-- HNSW index for vector similarity search (cosine distance)
CREATE INDEX IF NOT EXISTS idx_embeddings_hnsw
    ON embeddings USING hnsw (embedding vector_cosine_ops);
